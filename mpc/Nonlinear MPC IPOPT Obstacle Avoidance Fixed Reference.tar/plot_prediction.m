% Plot predicted positions along horizon
plot(Xi(1,1:size(Xi,2)), Xi(2,1:size(Xi,2)))
hold off
pause(1e-6)